<?php
session_start();
if($_SESSION['sid']=="")
{
header('location:index.php');
}
else{
 ?>
 <!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="">
	<meta name="description" content="">
	<!-- SITE TITLE -->
	<title>IT (Project-2)</title>

	<!-- STYLESHEETS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/templatemo-style.css">
	<link href='//fonts.googleapis.com/css?family=Raleway:400,300,600,700' rel='stylesheet' type='text/css'>
<!-- 

Ultra Profile

https://templatemo.com/tm-464-ultra-profile

-->
</head>

<body data-spy="scroll" data-target="#rock-navigation">
	
<section id="register" class="tm-register">
			<div class="navbar-header">
			<a href="home.php" class="sitetitle">IT</a>
				
				<a href="#" class="navbar-brand">OSE Myanmar Agent</a>
			</div>
			<nav class="collapse navbar-collapse" id="rock-navigation">
				<ul class="nav navbar-nav navbar-right main-navigation text-uppercase">
					<li><a href="home.php" class="selected">HOME</a></li>
					<li><a href="insert.php">INSERT</a></li>
					<li><a href="view-product.php">PRODUCT</a></li>
					<li><a href="view-order.php">ORDER</a></li>
					<li><a href="view-feedback.php">FEEDBACK</a></li>
					<li><a href="Logout.php">Log Out</a></li>
				</ul>
			</nav>
			<h1>Min Khant</h1>
					<h2>Online sale/Service Store</h2>
			<br><br><br><br><br>
			

	 <div id="navbar-main">
    	
       
       <h2><font color="red">Hello ...Welcome  Admin</h2><br><br><br><br><br><br><br><br><br><br><br><br></font>
        

        <div class="clear"></div>
    </div>
	<div class="col-md-1 col-sm-1"></div>
				<div class="col-md-12 col-sm-12">
					<p>Copyright &copy; 2024
                     <a href="https://www.ose168.com">Your's Company Name</a></p>
				</div>
				

				<?php }  ?>
				<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/smoothscroll.js"></script>
	<script src="js/jquery.nav.js"></script>
	<script src="js/isotope.js"></script>
	<script src="js/imagesloaded.min.js"></script>
	<script src="js/custom.js"></script>
</html>
</body>
</section>
				