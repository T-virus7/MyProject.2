<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="">
	<meta name="description" content="">
	<!-- SITE TITLE -->
	<title>IT (Project-2)</title>

	<!-- STYLESHEETS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/templatemo-style.css">
	<link href='//fonts.googleapis.com/css?family=Raleway:400,300,600,700' rel='stylesheet' type='text/css'>
<!-- 

Ultra Profile

https://templatemo.com/tm-464-ultra-profile

-->
</head>
<body data-spy="scroll" data-target="#rock-navigation">
	<!-- START NAVIGATION -->
	<div class="navbar navbar-default bs-dos-nav navbar-fixed-top sticky-navigation" role="navigation">
		<div class="container">

			<div class="navbar-header">
				<button class="navbar-toggle" data-toggle="collapse" data-target="#rock-navigation">
					<span class="icon icon-bar"></span>
					<span class="icon icon-bar"></span>
					<span class="icon icon-bar"></span>
				</button>
				<a href="#" class="navbar-brand">OSE Myanmar Agent</a>
			</div>
			<nav class="collapse navbar-collapse" id="rock-navigation">
				<ul class="nav navbar-nav navbar-right main-navigation text-uppercase">
					<li><a href="#home" class="smoothScroll">HOME</a></li>
					<li><a href="#work" class="smoothScroll">LAST PRODUCT</a></li>
					<li><a href="#portfolio" class="smoothScroll">MY PRODUCT</a></li>
					<li><a href="#resume" class="smoothScroll">ABOUT</a></li>
					<li><a href="#about" class="smoothScroll">CONTACT</a></li>
					<li><a href="#contact" class="smoothScroll">REGISTER</a></li>
				</ul>
			</nav>

		</div>
	</div>
	<!-- END NAVIGATION -->

	<!-- START HOME -->
	<section id="home" class="templatemo-home">
		<div class="container">
			<div class="row">
				<div class="col-md-2 col-sm-1"></div>
				<div class="col-md-8 col-sm-10">
					<h1 class="tm-home-title"><strong>Min Khant</strong></h1>
					<h2 class="tm-home-subtitle">Online sale/Service Store</h2>
					<p>WELCOME <strong>TO </strong>MY <strong>WEBSITE </strong></p>
					<p><strong>Let us work together </strong> Thank you.</p>
					<a href="product.php" class="btn btn-default smoothScroll tm-view-more-btn">Buy Now?</a>
				</div>
				<div class="col-md-2 col-sm-1"></div>
			</div>
		</div>
	</section>
	<!-- END HOME -->

	<!-- START work -->
	<section id="work" class="tm-padding-top-bottom-100">
		<div class="container">
			<div class="row">
				<div class="col-md-offset-1 col-md-11">
					<h2 class="title">Latest <strong>Tablet</strong></h2>						
				</div>
				<div class="col-md-4 col-sm-4">
					<div class="work-wrapper">
						<div class="work-wrapper-image">
						</div>
						<h3 class="text-uppercase tm-work-h3">OSE Tablet S3</h3>
						<hr>
						<p>.Android Version-10</p>
						<p>.Ram 4GB + Rom 64GB</p>
						<p>.Network-4G/4G</p>
						<p>.Battery-11000mAH(Type C)</p>
						<p>.Keyboard cover Present</p>
				
				</div>
				</div>
				<div class="col-md-4 col-sm-4">
					<div class="work-wrapper">
						<h3 class="text-uppercase tm-work-h3">OSE Tablet S5</h3>
						<hr>
						<p>.Android Version-11</p>
						<p>.Ram 8GB + Rom 128GB</p>
						<p>.Network-4G/4G</p>
						<p>.Display-10"</p>
						<p>.Camera-13MP,5MP</p>
						<p>.CPU-MTK.6762(8core)</p>
						<p>.Battery-10000mAH(Type C)</p>
						<p>.1 year service warranty</p>
					</div>
				</div>
				<div class="col-md-4 col-sm-4">
					<div class="work-wrapper">
						<h3 class="text-uppercase tm-work-h3">OSE Tablet S6</h3>
						<hr>
						<p>.OSE S6</p>
						<p>.Display-10.5</p>
						<p>.Android Version-12</p>
						<p>.Network-4G/4G</p>
						<p>.Camera-800/2000pixels
						<p>.Battery-10000mAH</p>
						<p>.Type-C(Cable)</p>
						<p>.1 year service warranty</p>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- END work -->

	<!-- START PORTFOLIO -->
	<section id="portfolio" class="tm-portfolio">
		<div class="container">
			<div class="row">
				<div class="col-md-12 wow bounce">
					<div class="title">
						<h2 class="tm-portfolio-title">My <strong>PRODUCT</strong></h2>
					</div>

					<!-- START ISO SECTION -->
					<div class="iso-section">
						<ul class="filter-wrapper clearfix">
							<li><a href="#" class="opc-main-bg selected" data-filter="*">All</a></li>
							<li><a href="#" class="opc-main-bg" data-filter=".html">Budget List</a></li>
						</ul>
						<div class="iso-box-section">
							<div class="iso-box-wrapper col4-iso-box">
								<div class="iso-box html photoshop wordpress mobile col-md-3 col-sm-3 col-xs-12">
									<div class="portfolio-thumb">
										<img src="images/portfolio-imgo1s.jpg" class="fluid-img" alt="portfolio img">
										<div class="portfolio-overlay">
											<h3 class="portfolio-item-title">OSE O1S</h3>
											<p>OSE O1S 10" 2+16GB(VERSION-7)TABLET</P> 
											<P>KS 262,500</p>
										</div>
									</div>
								</div>
								<div class="iso-box html wordpress mobile col-md-3 col-sm-3 col-xs-12">
									<div class="portfolio-thumb">
										<img src="images/portfolio-imgo7a.jpg" class="fluid-img" alt="portfolio img">
										<div class="portfolio-overlay">
											<h3 class="portfolio-item-title">OSE O7A(NEW ARRIVAL)</h3>
											<p>OSE O7A 7" 4+32GB(VERSION-8.1)TABLET</p>
											<P>KS 200,000</P>
										</div>
									</div>
								</div>
								<div class="iso-box wordpress col-md-3 col-sm-3 col-xs-12">
									<div class="portfolio-thumb">
										<img src="images/portfolio-imgs2.jpg" class="fluid-img" alt="portfolio img">
										<div class="portfolio-overlay">
											<h3 class="portfolio-item-title">OSE S2</h3>
											<p>OSE S2 10" 6+128GB(VERSION-9)TABLET</p>
											<P>KS 390,000</p>
										</div>
									</div>
								</div>
								<div class="iso-box html mobile col-md-3 col-sm-3 col-xs-12">
									<div class="portfolio-thumb">
										<img src="images/portfolio-imgo8p.jpg" class="fluid-img" alt="portfolio img">
										<div class="portfolio-overlay">
											<h3 class="portfolio-item-title">OSE O8P</h3>
											<p>OSE O8P 8" 2+16GB(VERSION-7.0)TABLET</p>
											<P>KS 200,000</P>
										</div>
									</div>
								</div>
								<div class="iso-box wordpress col-md-3 col-sm-3 col-xs-12">
									<div class="portfolio-thumb">
										<img src="images/portfolio-imgh2.jpg" class="fluid-img" alt="portfolio img">
										<div class="portfolio-overlay">
											<h3 class="portfolio-item-title">OSE S3</h3>
											<p>OSE S3 10.1" 4+64GB(Version-10)TABLET</p>
											<P>KS 437,500</P>
										</div>
									</div>
								</div>
								<div class="iso-box html photoshop col-md-3 col-sm-3 col-xs-12">
									<div class="portfolio-thumb">
										<img src="images/portfolio-imgo8b.jpg" class="fluid-img" alt="portfolio img">
										<div class="portfolio-overlay">
											<h3 class="portfolio-item-title">OSE O8b</h3>
											<p>OSE O8b 8" 4+32GB(VERSION-8.1)TABLET</p>
											<P>KS 262,500</p>
										</div>
									</div>
								</div>
								<div class="iso-box photoshop col-md-3 col-sm-3 col-xs-12">
									<div class="portfolio-thumb">
										<img src="images/portfolio-imgs5.jpg" class="fluid-img" alt="portfolio img">
										<div class="portfolio-overlay">
											<h3 class="portfolio-item-title">OSE S5</h3>
											<p>OSE S5 10.1" 8+128GB(VERSION-11)TABLET</p>
											<p>KS 562500</p>
										</div>
									</div>
								</div>
								<div class="iso-box wordpress col-md-3 col-sm-3 col-xs-12">
									<div class="portfolio-thumb">
										<img src="images/portfolio-imgs6.jpg" class="fluid-img" alt="portfolio img">
										<div class="portfolio-overlay">
											<h3 class="portfolio-item-title">OSE S6</h3>
											<p>OSE S6 10.5" 10+128GB(VRSION-12)TABLET</p>
											<p>KS 650000</p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- END PORTFOLIO -->

	<!-- START RESUME -->
	<section id="resume" class="tm-padding-top-bottom-100">
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-sm-6">					
					<h2 class="title">My <strong>Profile</strong></h2>
					<p><span class="tm-info-label">Name</span> Min Khant Hein</p>
					<p><span class="tm-info-label">Birthday</span> December 19, 1996</p>
					<p><span class="tm-info-label">Address</span> 344/(A),1 Street,Insein Township,Yangon</p>
					<p><span class="tm-info-label">Phone</span> 09953286796 | 09953286795</p>
					<p><span class="tm-info-label">Email</span> heinkhantmin121996@gmail.com</p>
					<p><span class="tm-info-label">Website</span> <a href="#" class="tm-red-text">www.ose myanmar.com</a></p>
				</div>
				<div class="col-md-6 col-sm-6">
					<h2 class="title"><strong>Website</strong> About </h2>
					<p>Built in OSE Tablet Google play store,Online learning,Office,Business,Restaurant,Use as you like Facebook,Viber,Messanger,Youtube,Zoom.</p>
					<h4 class="tm-progress-label">Service <small class="progress-percent-small">100%</small></h4>
					<div class="progress tm-progress">
						<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%;"></div>
					</div>
					<h4 class="tm-progress-label">Review <small class="progress-percent-small">90%</small></h4>
					<div class="progress tm-progress">
						<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width: 90%;"></div>
					</div>
					<h4 class="tm-progress-label">Tablet Quality <small class="progress-percent-small">80%</small></h4>
					<div class="progress tm-progress">
						<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%;"></div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- END RESUME -->

	<!-- START ABOUT -->
	<section id="about" class="tm-about">
		<div class="container">
			<div class="row">
				<div class="col-md-offset-6 col-md-6 col-sm-offset-6 col-sm-7">
					<div class="title">
						<h2>This is <strong>me</strong></h2>
						<h1 class="tm-red-text">OSE Tablet <strong>Agent</strong></h1>
					</div>
					<p>How long will an OSE Tablet last?</p>
					<p>To calculate how much you will use an OSE Tablet,you must first know first know how will use it.</p>
					<p>Are you the one who will maintain discipline and use it? (OR) do you want to be rough and casual?</p>
					<p>If you keep it properly, you can use it for 2 to 5 years.</p>
					<p>Even if you use it roughly,you can still use it comfortably for 1 to 2 years.</p>
					<p>But....it is important to carefully choose the tablet.</p>
					<p>If you intent to use it for years,don't forget to prioritize the quality of the tablet.</p>
					<p>There is also a quality OSE Tablet.</P>
					<p>You want to continue using it for along time,please read the post up.</p> 
				</div>
			</div>
		</div>
	</section>
	<!-- END ABOUT -->

	<!-- START CONTACT -->
	<section id="contact" class="tm-contact">
<?php
error_reporting(1);
include("connection.php");
if($_POST['sub'])
{ 
$name=$_POST['t1'];
$email=$_POST['t2'];
$phone=$_POST['t3'];
$mesg=$_POST['t4'];
if(mysql_query("insert into content(name,email,phone,mesg) values('$name','$email','$phone','$mesg')"))
{$er="<font color='red' size='+1'> Message sent successfully</font>"; }
}

?>	
		<div class="container">
			<div class="row">
				<div class="col-md-12">					
					<h2 class="title">Contact <strong>Information</strong></h2>
					<hr>					
				</div>
				<div class="col-md-1 col-sm-1"></div>
				<div class="col-md-10 col-sm-10">
					<form action="#" name="contact" method="post">
						<div class="col-md-6 col-sm-6">
							<input class="form-control" type="text" placeholder="Your Name" id="t1" name="t1" class="required input_field" />
						</div>
						<div class="col-md-6 col-sm-6">
							<input class="form-control" type="email" placeholder="Your Email" id="t2" name="t2" class="validate-email required input_field" />
						</div>
						<div class="col-md-12 col-sm-12">
							<input class="form-control" type="text" placeholder="Your Phone" id="t3" name="t3" class="required input_field" />
							<textarea class="form-control" placeholder="Your Message" rows="6" id="t4" name="t4" class="required"></textarea>
						</div>
						<div class="col-md-offset-2 col-md-8 col-sm-offset-2 col-sm-8">
							<input class="form-control" name="sub"  id="sub" type="submit" value="Send" class="submit_button" /><br><br><br><br><br><br>
						</div>
					</form>
					<h2><?php echo $er;?></h2>
				</div>
				<div class="clear"></div>
	<!-- END CONTACT -->
	<!-- START REGISTER -->
			<section id="register" class="tm-register">
<?php
error_reporting(1);
include("connection.php");
if($_POST['sub'])
{ 
$name=$_POST['t1'];
$email=$_POST['t2'];
$password=$_POST['t3'];
$phone=$_POST['t4'];
$city=$_POST['t5'];
$town=$_POST['t6'];
if(mysql_query("insert into register(name,email,password,phone,city,township) values('$name','$email','$password','$phone','$city','$town')"))
{
//echo "<script>location.href='reg_success.php?email=$email'</script>"; 
header("location:reg_success.php?name=$name & email=$email");}
else {$error= "user already exists";}}

?>
		<div class="container">
			<div class="row">
				<div class="col-md-12">					
					<h2 class="title">REGISTER <strong>FORM</strong></h2>
					<hr>					
				</div>
				<div class="col-md-1 col-sm-1"></div>
				<div class="col-md-10 col-sm-10">
					<form action="#" method="post">
						<div class="col-md-6 col-sm-6">
							<input class="form-control" type="text" id="t1" name="t1" placeholder="Your Name" class="input_field" />
						</div>
						<div class="col-md-6 col-sm-6">
							<input class="form-control" type="email" id="t2" name="t2" placeholder="Your Email" class="input_field" />
						</div>
						<div class="col-md-6 col-sm-6">
							<input class="form-control" type="text" id="t4" name="t4" placeholder="Your phone" class="input_field" />
						</div>
						<div class="col-md-6 col-sm-6">
							<input class="form-control" type="email" id="t3" name="t3" placeholder="Your password" class="input_field" />
						</div>
						<div class="col-md-6 col-sm-6">
							<input class="form-control" type="city" id="t5" name="t5" placeholder="Your city" class="input_field" />
						</div>
						<div class="col-md-6 col-sm-6">
							<input class="form-control" type="country" id="t6" name="t6" placeholder="Your country" class="input_field" /> 
						</div>
						
						<div class="col-md-offset-2 col-md-8 col-sm-offset-2 col-sm-8">
							<input class="form-control" type="submit" value="Register" name="sub" id="sub" class="submit_button" />
						</div>
						<label><?php echo "<font color='red'>$error</font>";?></label>
					</form>
					 <div class="clear"></div>
				</div>
				<div class="col-md-1 col-sm-1"></div>
				<div class="col-md-12 col-sm-12">
					<p>Copyright &copy; 2024
                     <a href="https://www.ose168.com">Your's Company Name</a></p>
				</div>
			</div>
		</div>
	</section>
	<!-- END REGISTER -->
	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/smoothscroll.js"></script>
	<script src="js/jquery.nav.js"></script>
	<script src="js/isotope.js"></script>
	<script src="js/imagesloaded.min.js"></script>
	<script src="js/custom.js"></script>
</body>
</html>