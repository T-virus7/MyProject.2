<?php
error_reporting(1);
session_start();
$i=$_REQUEST['img'];
$_SESSION['sid']=$_POST['id'];
include("connection.php");
$i=$_REQUEST['img'];
if($_POST['ord'])
{ 
$prodno=$_POST['prodno'];
$price=$_POST['price'];
$name=$_POST['nam'];
$phone=$_POST['pho'];
$add=$_POST['add'];
$ordno=ord.rand(100,500);
if(mysql_query("insert into orders(productno,price,name,phone,address,order_no) values('$prodno','$price','$name','$phone','$add','$ordno')"))
{
//echo "<script>location.href='ordersent.php?prod'</script>";
header("location:ordersent.php?order_no=$ordno");  }
else {$error= "user already exists";}}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="">
	<meta name="description" content="">
	<!-- SITE TITLE -->
	<title>IT (Project-2)</title>

	<!-- STYLESHEETS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/templatemo-style.css">
	<link href='//fonts.googleapis.com/css?family=Raleway:400,300,600,700' rel='stylesheet' type='text/css'>
<!-- 

Ultra Profile

https://templatemo.com/tm-464-ultra-profile

-->
</head>
<body data-spy="scroll" data-target="#rock-navigation">
<section id="register" class="tm-register">
		<div class="container">
			<div class="row">
				<div class="col-md-12">					
					<h2 class="title">ORDER </strong>FORM</h2>
					<hr>
<?php
			include("connection.php");
			$sel=mysql_query("select * from item  where img='$i' ");
			$mat=mysql_fetch_array($sel);
			
			
			?>					
				</div>
				<div class="col-md-1 col-sm-1"></div>
				<div class="col-md-10 col-sm-10">
					<form action="#" method="post">
						<div class="col-md-6 col-sm-6">
						 <label>Product No </label>
							<input class="form-control" type="text" class="input_field"  name="prodno" id="prodno" value="<?php echo $mat['prod_no'];?>">
						</div>
						<div class="col-md-6 col-sm-6">
						<label>Price </label>
							<input class="form-control" type="text" name="price" class="input_field" id="price" value="<?php echo $mat['price'];?>">
						</div>
						<div class="col-md-6 col-sm-6">
						<label>Name </label>
							<input class="form-control" type="text" name="nam" id="nam" class="input_field" />
						</div>
						<div class="col-md-6 col-sm-6">
						<label>Phone </label>
							<input class="form-control" type="text" name="pho" id="pho" class="input_field" />
						</div>
						<div class="col-md-12 col-sm-12">
						<label>Address </label>
							 <textarea class="form-control" id="add" name="add" rows="0" cols="0" class="required"></textarea>
						</div>
						<div class="col-md-offset-2 col-md-8 col-sm-offset-2 col-sm-8">
							<input class="form-control" type="submit"  name="ord" id="ord" value="sent order" class="submit_button" /><br><br><br><br>
						</div>
					</form>
					 <div class="clear"></div>
				</div>
				<div class="col-md-1 col-sm-1"></div>
				<div class="col-md-12 col-sm-12">
					<p>Copyright &copy; 2024
                     <a href="https://www.ose168.com">Your's Company Name</a></p>
				</div>
			</div>
		</div>
	</section>
	</body>
	</html>